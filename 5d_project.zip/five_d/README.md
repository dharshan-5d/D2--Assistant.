# 5D

Small, fast Android AI assistant with a calm British "butler" voice.

- Bring your own API key: OpenAI, Gemini, Groq, OpenRouter, Anthropic, or any OpenAI-compatible endpoint
- Hands-free voice mode (listen, think, speak, repeat)
- Device commands: timer, alarm, flashlight, battery, time, date, open apps, call, search, quick maths
- Key stored with Android Keystore (flutter_secure_storage); chats stay on the phone
- The Android project files are generated fresh by the build workflow, so Flutter updates do not break the build
