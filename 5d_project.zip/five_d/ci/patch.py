import re, shutil, pathlib

root = pathlib.Path('android')
APP_ID = 'com.fived.assistant'

# 1. Force application id / namespace
for name in ('app/build.gradle.kts', 'app/build.gradle'):
    p = root / name
    if p.exists():
        s = p.read_text()
        s = re.sub(r'(namespace\s*=?\s*)["\'][^"\']+["\']', r'\1"%s"' % APP_ID, s)
        s = re.sub(r'(applicationId\s*=?\s*)["\'][^"\']+["\']', r'\1"%s"' % APP_ID, s)
        p.write_text(s)

# 2. Replace the generated MainActivity with ours
for d in ('kotlin', 'java'):
    shutil.rmtree(root / 'app/src/main' / d, ignore_errors=True)
dest = root / 'app/src/main/kotlin/com/fived/assistant'
dest.mkdir(parents=True, exist_ok=True)
shutil.copy('ci/MainActivity.kt', dest / 'MainActivity.kt')

# 3. Patch the manifest
m = root / 'app/src/main/AndroidManifest.xml'
s = m.read_text()

perms = '''    <uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.RECORD_AUDIO"/>
    <uses-permission android:name="android.permission.BLUETOOTH"/>
    <uses-permission android:name="android.permission.BLUETOOTH_ADMIN"/>
    <uses-permission android:name="android.permission.BLUETOOTH_CONNECT"/>
    <uses-permission android:name="com.android.alarm.permission.SET_ALARM"/>
'''
queries = '''        <intent><action android:name="android.speech.RecognitionService"/></intent>
        <intent><action android:name="android.intent.action.TTS_SERVICE"/></intent>
        <package android:name="com.whatsapp"/>
        <package android:name="com.android.chrome"/>
        <package android:name="com.google.android.youtube"/>
        <package android:name="com.google.android.apps.maps"/>
        <package android:name="com.google.android.gm"/>
        <package android:name="com.instagram.android"/>
        <package android:name="org.telegram.messenger"/>
        <package android:name="com.spotify.music"/>
        <package android:name="com.facebook.katana"/>
        <package android:name="com.facebook.orca"/>
'''

if '</queries>' in s:
    s = s.replace('</queries>', queries + '    </queries>', 1)
    s = s.replace('<application', perms + '    <application', 1)
else:
    s = s.replace('<application', perms + '    <queries>\n' + queries + '    </queries>\n    <application', 1)

s = re.sub(r'android:label="[^"]*"', 'android:label="5D"', s, count=1)
m.write_text(s)

# 4. Launcher icon (adaptive icon wins on Android 8+)
shutil.copytree('ci/res', root / 'app/src/main/res', dirs_exist_ok=True)
print('patched OK')
