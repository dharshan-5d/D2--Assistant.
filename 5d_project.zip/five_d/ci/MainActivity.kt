package com.fived.assistant

import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.net.Uri
import android.os.BatteryManager
import android.provider.AlarmClock
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val channel = "com.fived.assistant/device"

    private val apps = mapOf(
        "whatsapp" to "com.whatsapp",
        "chrome" to "com.android.chrome",
        "youtube" to "com.google.android.youtube",
        "maps" to "com.google.android.apps.maps",
        "gmail" to "com.google.android.gm",
        "instagram" to "com.instagram.android",
        "telegram" to "org.telegram.messenger",
        "spotify" to "com.spotify.music",
        "facebook" to "com.facebook.katana",
        "messenger" to "com.facebook.orca"
    )

    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, channel)
            .setMethodCallHandler { call, result ->
                try {
                    when (call.method) {
                        "battery" -> {
                            val m = getSystemService(Context.BATTERY_SERVICE) as BatteryManager
                            result.success(m.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY))
                        }
                        "torch" -> setTorch(call.argument<Boolean>("enabled") ?: false, result)
                        "timer" -> {
                            val seconds = call.argument<Int>("seconds") ?: 0
                            if (seconds <= 0 || seconds > 86400) {
                                result.error("BAD_DURATION", "Timer must be between 1 second and 24 hours.", null)
                            } else {
                                startActivity(
                                    Intent(AlarmClock.ACTION_SET_TIMER)
                                        .putExtra(AlarmClock.EXTRA_LENGTH, seconds)
                                        .putExtra(AlarmClock.EXTRA_MESSAGE, "5D")
                                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                                )
                                result.success(true)
                            }
                        }
                        "alarm" -> {
                            val hour = call.argument<Int>("hour") ?: -1
                            val minute = call.argument<Int>("minute") ?: 0
                            if (hour !in 0..23 || minute !in 0..59) {
                                result.error("BAD_TIME", "That is not a valid alarm time.", null)
                            } else {
                                startActivity(
                                    Intent(AlarmClock.ACTION_SET_ALARM)
                                        .putExtra(AlarmClock.EXTRA_HOUR, hour)
                                        .putExtra(AlarmClock.EXTRA_MINUTES, minute)
                                        .putExtra(AlarmClock.EXTRA_MESSAGE, "5D")
                                        .putExtra(AlarmClock.EXTRA_SKIP_UI, true)
                                )
                                result.success(true)
                            }
                        }
                        "openApp" -> {
                            val name = (call.argument<String>("app") ?: "").lowercase()
                            if (name == "settings") {
                                startActivity(Intent(Settings.ACTION_SETTINGS))
                                result.success(true)
                            } else {
                                val pkg = apps[name]
                                val intent = pkg?.let { packageManager.getLaunchIntentForPackage(it) }
                                if (intent == null) {
                                    result.error("APP_MISSING", "$name is not installed.", null)
                                } else {
                                    startActivity(intent)
                                    result.success(true)
                                }
                            }
                        }
                        "dial" -> {
                            val number = call.argument<String>("number") ?: ""
                            startActivity(Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null)))
                            result.success(true)
                        }
                        "search" -> {
                            val q = call.argument<String>("query") ?: ""
                            startActivity(
                                Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q)))
                            )
                            result.success(true)
                        }
                        else -> result.notImplemented()
                    }
                } catch (e: Exception) {
                    result.error("DEVICE_ACTION_FAILED", e.message ?: "Device action failed.", null)
                }
            }
    }

    private fun setTorch(enabled: Boolean, result: MethodChannel.Result) {
        try {
            val manager = getSystemService(Context.CAMERA_SERVICE) as CameraManager
            val id = manager.cameraIdList.firstOrNull {
                manager.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
            }
            if (id == null) {
                result.error("NO_FLASH", "No flashlight found on this phone.", null)
            } else {
                manager.setTorchMode(id, enabled)
                result.success(true)
            }
        } catch (e: Exception) {
            result.error("TORCH_FAILED", e.message ?: "Could not control the flashlight.", null)
        }
    }
}
