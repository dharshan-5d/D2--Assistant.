import 'package:flutter/material.dart';

import 'state.dart';
import 'ui/chat_screen.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    await app.init().timeout(const Duration(seconds: 8));
  } catch (_) {}
  runApp(const FiveDApp());
}

ThemeData _theme(Brightness b) {
  final dark = b == Brightness.dark;
  final base = ColorScheme.fromSeed(seedColor: const Color(0xFF00B8E6), brightness: b);
  final scheme = base.copyWith(
    primary: dark ? const Color(0xFF38D5FF) : const Color(0xFF00749A),
    surface: dark ? const Color(0xFF0B1220) : const Color(0xFFF4F8FC),
  );
  return ThemeData(
    useMaterial3: true,
    colorScheme: scheme,
    scaffoldBackgroundColor: scheme.surface,
    appBarTheme: AppBarTheme(
      backgroundColor: scheme.surface,
      elevation: 0,
      scrolledUnderElevation: 0,
    ),
  );
}

class FiveDApp extends StatelessWidget {
  const FiveDApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) => MaterialApp(
        title: '5D',
        debugShowCheckedModeBanner: false,
        theme: _theme(Brightness.light),
        darkTheme: _theme(Brightness.dark),
        themeMode: app.themeMode,
        home: const ChatScreen(),
      ),
    );
  }
}
