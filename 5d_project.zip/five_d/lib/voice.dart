import 'package:flutter_tts/flutter_tts.dart';
import 'package:speech_to_text/speech_to_text.dart';

/// Wraps the phone's own text-to-speech and speech-recognition engines.
class VoiceService {
  final FlutterTts _tts = FlutterTts();
  final SpeechToText _stt = SpeechToText();

  bool sttReady = false;
  void Function(String status)? onStatus;
  void Function(String error)? onError;

  Future<void> initTts() async {
    try {
      await _tts.awaitSpeakCompletion(true);
      await _tts.setVolume(1.0);
    } catch (_) {}
  }

  Future<List<Map<String, String>>> loadVoices() async {
    try {
      final v = await _tts.getVoices.timeout(const Duration(seconds: 4));
      final out = <Map<String, String>>[];
      if (v is List) {
        for (final e in v) {
          if (e is Map) {
            final n = e['name']?.toString();
            final l = e['locale']?.toString();
            if (n != null && l != null) out.add({'name': n, 'locale': l});
          }
        }
      }
      return out;
    } catch (_) {
      return [];
    }
  }

  Future<void> applyVoice({
    String? name,
    String? locale,
    required double pitch,
    required double rate,
  }) async {
    try {
      await _tts.setLanguage(locale == null || locale.isEmpty ? 'en-GB' : locale);
      if (name != null && name.isNotEmpty) {
        await _tts.setVoice({'name': name, 'locale': locale ?? 'en-GB'});
      }
      await _tts.setPitch(pitch);
      await _tts.setSpeechRate(rate);
    } catch (_) {}
  }

  Future<void> speak(String text) async {
    final t = cleanForSpeech(text);
    if (t.isEmpty) return;
    try {
      await _tts.stop();
      await _tts.speak(t);
    } catch (_) {}
  }

  Future<void> stopSpeaking() async {
    try {
      await _tts.stop();
    } catch (_) {}
  }

  Future<bool> initStt() async {
    try {
      sttReady = await _stt.initialize(
        onStatus: (s) => onStatus?.call(s),
        onError: (e) => onError?.call(e.errorMsg),
      );
    } catch (_) {
      sttReady = false;
    }
    return sttReady;
  }

  Future<void> listen(void Function(String words, bool isFinal) onWords) async {
    await _stt.listen(
      onResult: (r) => onWords(r.recognizedWords, r.finalResult),
      listenFor: const Duration(seconds: 40),
      pauseFor: const Duration(seconds: 3),
    );
  }

  Future<void> stopListening() async {
    try {
      await _stt.stop();
    } catch (_) {}
  }

  Future<void> cancelListening() async {
    try {
      await _stt.cancel();
    } catch (_) {}
  }
}

String cleanForSpeech(String s) {
  var t = s;
  t = t.replaceAll(RegExp(r'```[\s\S]*?```'), ' code omitted. ');
  t = t.replaceAllMapped(RegExp(r'\[([^\]]+)\]\([^)]+\)'), (m) => m.group(1) ?? '');
  t = t.replaceAll(RegExp(r'https?://\S+'), 'link');
  t = t.replaceAll(RegExp(r'[*_`#>]+'), '');
  t = t.replaceAll(RegExp(r'^\s*[-•]\s+', multiLine: true), '');
  t = t.replaceAll(RegExp(r'\s+'), ' ').trim();
  if (t.length > 3000) t = t.substring(0, 3000);
  return t;
}
