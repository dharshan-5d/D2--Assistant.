import 'dart:async';
import 'dart:convert';
import 'dart:io';

import 'package:http/http.dart' as http;

class Provider {
  final String id;
  final String label;
  final String baseUrl;
  final String model;
  final bool anthropic;
  const Provider(this.id, this.label, this.baseUrl, this.model, {this.anthropic = false});
}

const List<Provider> providers = [
  Provider('openai', 'OpenAI', 'https://api.openai.com/v1', 'gpt-4o-mini'),
  Provider('gemini', 'Google Gemini', 'https://generativelanguage.googleapis.com/v1beta/openai', 'gemini-2.0-flash'),
  Provider('groq', 'Groq', 'https://api.groq.com/openai/v1', 'llama-3.3-70b-versatile'),
  Provider('openrouter', 'OpenRouter', 'https://openrouter.ai/api/v1', 'openrouter/auto'),
  Provider('anthropic', 'Anthropic Claude', 'https://api.anthropic.com', 'claude-sonnet-4-5', anthropic: true),
  Provider('custom', 'Custom (any OpenAI-compatible)', '', ''),
];

Provider providerOf(String id) {
  for (final p in providers) {
    if (p.id == id) return p;
  }
  return providers.last;
}

class ApiException implements Exception {
  final String message;
  ApiException(this.message);
  @override
  String toString() => message;
}

class AiClient {
  static Future<String> chat({
    required String providerId,
    required String baseUrl,
    required String model,
    required String apiKey,
    required String system,
    required List<Map<String, String>> messages,
  }) async {
    final base = baseUrl.trim().replaceAll(RegExp(r'/+$'), '');
    if (base.isEmpty || model.trim().isEmpty) {
      throw ApiException('Base URL and model are required.');
    }
    if (!base.startsWith('https://')) {
      throw ApiException('Base URL must start with https://');
    }
    final key = apiKey.trim();
    if (key.isEmpty) throw ApiException('API key is missing.');

    final p = providerOf(providerId);
    final Uri uri;
    final Map<String, String> headers;
    final Map<String, dynamic> body;

    if (p.anthropic) {
      uri = Uri.parse('${base.replaceAll(RegExp(r'/v1$'), '')}/v1/messages');
      headers = {
        'content-type': 'application/json',
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
      };
      body = {
        'model': model.trim(),
        'max_tokens': 2048,
        'messages': messages,
        if (system.trim().isNotEmpty) 'system': system,
      };
    } else {
      uri = Uri.parse('$base/chat/completions');
      headers = {
        'content-type': 'application/json',
        'authorization': 'Bearer $key',
      };
      body = {
        'model': model.trim(),
        'messages': [
          if (system.trim().isNotEmpty) {'role': 'system', 'content': system},
          ...messages,
        ],
      };
    }

    http.Response res;
    try {
      res = await http
          .post(uri, headers: headers, body: jsonEncode(body))
          .timeout(const Duration(seconds: 90));
    } on TimeoutException {
      throw ApiException('The request timed out. Please try again.');
    } on SocketException {
      throw ApiException('No internet connection.');
    } on http.ClientException {
      throw ApiException('No internet connection.');
    } catch (e) {
      throw ApiException('Network error: $e');
    }

    final text = utf8.decode(res.bodyBytes, allowMalformed: true);
    if (res.statusCode < 200 || res.statusCode > 299) {
      throw ApiException(_explain(res.statusCode, text));
    }

    try {
      final json = jsonDecode(text) as Map<String, dynamic>;
      if (p.anthropic) {
        final content = json['content'] as List<dynamic>;
        final sb = StringBuffer();
        for (final b in content) {
          if (b is Map && b['type'] == 'text') sb.write(b['text']);
        }
        final out = sb.toString().trim();
        return out.isEmpty ? '(empty reply)' : out;
      }
      final choices = json['choices'] as List<dynamic>;
      final msg = (choices.first as Map<String, dynamic>)['message'] as Map<String, dynamic>;
      final out = (msg['content'] ?? '').toString().trim();
      return out.isEmpty ? '(empty reply)' : out;
    } catch (_) {
      throw ApiException('Unexpected reply from the provider. Check the base URL and model.');
    }
  }

  static String _explain(int code, String raw) {
    var detail = raw;
    try {
      final j = jsonDecode(raw);
      dynamic e = j;
      if (j is List && j.isNotEmpty) e = j.first;
      if (e is Map && e['error'] != null) {
        final err = e['error'];
        if (err is Map && err['message'] != null) {
          detail = err['message'].toString();
        } else if (err is String) {
          detail = err;
        }
      }
    } catch (_) {}
    if (detail.length > 250) detail = detail.substring(0, 250);
    final head = switch (code) {
      401 || 403 => 'Key rejected ($code). Check your API key.',
      404 => 'Not found (404). Check the base URL and model name.',
      429 => 'Rate limit or quota reached (429). Wait a bit and try again.',
      _ => 'Error $code.',
    };
    return detail.trim().isEmpty ? head : '$head\n$detail';
  }
}
