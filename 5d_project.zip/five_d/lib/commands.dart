import 'package:flutter/services.dart';

const MethodChannel _device = MethodChannel('com.fived.assistant/device');

const Set<String> _knownApps = {
  'whatsapp', 'chrome', 'youtube', 'maps', 'gmail', 'instagram',
  'telegram', 'spotify', 'facebook', 'messenger', 'settings',
};

String _two(int n) => n.toString().padLeft(2, '0');

String _duration(int s) {
  final h = s ~/ 3600;
  final m = (s % 3600) ~/ 60;
  final sec = s % 60;
  final parts = <String>[];
  if (h > 0) parts.add('$h hour${h == 1 ? '' : 's'}');
  if (m > 0) parts.add('$m minute${m == 1 ? '' : 's'}');
  if (sec > 0) parts.add('$sec second${sec == 1 ? '' : 's'}');
  return parts.join(' ');
}

String _num(double v) {
  if (v == v.roundToDouble()) return v.toInt().toString();
  var s = v.toStringAsFixed(4);
  s = s.replaceAll(RegExp(r'0+$'), '');
  return s.replaceAll(RegExp(r'\.$'), '');
}

/// Handles phone commands locally. Returns the reply, or null if the text
/// is not a local command (then it goes to the AI).
Future<String?> tryLocalCommand(String raw, String who) async {
  final original = raw.trim();
  var t = original.toLowerCase().replaceAll(RegExp(r'[?!.,]+$'), '').trim();
  t = t.replaceAll(RegExp(r'^(hey |ok |okay )?(jarvis|five d|5d)[, ]+'), '');
  t = t.replaceAll(RegExp(r'^(please|can you|could you|would you)\s+'), '');

  try {
    // Battery
    if (RegExp(r'\bbattery\b').hasMatch(t) &&
        RegExp(r'\b(level|percent|percentage|charge|left|how much|status|what)\b').hasMatch(t)) {
      final pct = await _device.invokeMethod<int>('battery');
      return 'Battery is at ${pct ?? 0} percent, $who.';
    }

    // Time and date
    if (RegExp(r"^(what('s| is) the time|what time is it|current time|time)$").hasMatch(t)) {
      final n = DateTime.now();
      final h12 = n.hour % 12 == 0 ? 12 : n.hour % 12;
      return "It is $h12:${_two(n.minute)} ${n.hour < 12 ? 'AM' : 'PM'}, $who.";
    }
    if (RegExp(r"^(what('s| is) (the )?(date|day)( today)?|today'?s date|what day is it|date)$").hasMatch(t)) {
      const days = ['Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday', 'Sunday'];
      const months = [
        'January', 'February', 'March', 'April', 'May', 'June', 'July',
        'August', 'September', 'October', 'November', 'December'
      ];
      final n = DateTime.now();
      return "Today is ${days[n.weekday - 1]}, ${months[n.month - 1]} ${n.day}, ${n.year}, $who.";
    }

    // Timer
    final tm = RegExp(r'(\d+)\s*(second|sec|minute|min|hour|hr)s?\s*timer').firstMatch(t) ??
        RegExp(r'timer\s*(?:for\s*)?(\d+)\s*(second|sec|minute|min|hour|hr)s?').firstMatch(t);
    if (tm != null) {
      final n = int.parse(tm.group(1)!);
      final u = tm.group(2)!;
      final mult = u.startsWith('h') ? 3600 : (u.startsWith('m') ? 60 : 1);
      final seconds = n * mult;
      await _device.invokeMethod('timer', {'seconds': seconds});
      return 'Timer set for ${_duration(seconds)}, $who.';
    }

    // Alarm
    if (t.contains('alarm')) {
      final am = RegExp(r'alarm\s*(?:for\s*|at\s*)?(\d{1,2})(?::(\d{2}))?\s*(a\.?m\.?|p\.?m\.?)?').firstMatch(t);
      if (am != null) {
        var h = int.parse(am.group(1)!);
        final min = int.tryParse(am.group(2) ?? '0') ?? 0;
        final ap = (am.group(3) ?? '').replaceAll('.', '');
        if (ap == 'pm' && h < 12) h += 12;
        if (ap == 'am' && h == 12) h = 0;
        await _device.invokeMethod('alarm', {'hour': h, 'minute': min});
        final h12 = h % 12 == 0 ? 12 : h % 12;
        return 'Alarm set for $h12:${_two(min)} ${h < 12 ? 'AM' : 'PM'}, $who.';
      }
    }

    // Flashlight
    if (RegExp(r'\b(flash ?light|torch)\b').hasMatch(t)) {
      final off = RegExp(r'\b(off|disable)\b').hasMatch(t);
      await _device.invokeMethod('torch', {'enabled': !off});
      return 'Flashlight ${off ? 'off' : 'on'}, $who.';
    }

    // Open an app
    final open = RegExp(r'^(?:open|launch|start)\s+(?:the\s+)?(.+?)(?:\s+app)?$').firstMatch(t);
    if (open != null) {
      var name = open.group(1)!.trim();
      name = name.replaceAll('google maps', 'maps').replaceAll('google chrome', 'chrome').replaceAll('whats app', 'whatsapp');
      if (_knownApps.contains(name)) {
        try {
          await _device.invokeMethod('openApp', {'app': name});
          return 'Opening $name, $who.';
        } on PlatformException {
          return "It doesn't look like $name is installed, $who.";
        }
      }
    }

    // Dial
    final dial = RegExp(r'^(?:dial|call)\s+([+\d][\d\s-]{4,})$').firstMatch(t);
    if (dial != null) {
      final number = dial.group(1)!.replaceAll(RegExp(r'[^+\d]'), '');
      await _device.invokeMethod('dial', {'number': number});
      return 'Opening the dialer, $who.';
    }

    // Web search
    final search = RegExp(r'^(?:search|google|look up)\s+(?:for\s+)?(.+)$', caseSensitive: false).firstMatch(original);
    if (search != null) {
      final q = search.group(1)!.trim();
      await _device.invokeMethod('search', {'query': q});
      return 'Searching for $q, $who.';
    }

    // Quick maths
    var mt = t
        .replaceAll('multiplied by', '*')
        .replaceAll('divided by', '/')
        .replaceAll('plus', '+')
        .replaceAll('minus', '-')
        .replaceAll('times', '*')
        .replaceAll(RegExp(r'(?<=\d)\s*x\s*(?=\d)'), '*');
    mt = mt.replaceAll(RegExp(r"^(what is |what's |calculate |work out )"), '');
    final math = RegExp(r'^(-?\d+(?:\.\d+)?)\s*([+\-*/])\s*(-?\d+(?:\.\d+)?)$').firstMatch(mt);
    if (math != null) {
      final a = double.parse(math.group(1)!);
      final b = double.parse(math.group(3)!);
      final op = math.group(2)!;
      if (op == '/' && b == 0) return 'Division by zero is undefined, $who.';
      final r = switch (op) { '+' => a + b, '-' => a - b, '*' => a * b, _ => a / b };
      return 'That comes to ${_num(r)}, $who.';
    }
  } on PlatformException catch (e) {
    return "I couldn't do that, $who. ${e.message ?? ''}".trim();
  } on MissingPluginException {
    return "That phone feature isn't available in this build, $who.";
  } catch (_) {
    return null;
  }
  return null;
}
