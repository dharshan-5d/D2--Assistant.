import 'dart:async';
import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'api.dart';
import 'commands.dart';
import 'voice.dart';

enum Status { idle, listening, thinking, speaking }

const String defaultInstructions = 'You are 5D, a helpful, honest personal assistant.';

class ChatMessage {
  final String role;
  final String text;
  final bool error;
  ChatMessage(this.role, this.text, {this.error = false});

  Map<String, dynamic> toJson() => {'role': role, 'text': text, 'error': error};
  factory ChatMessage.fromJson(Map<String, dynamic> j) =>
      ChatMessage(j['role'] as String, j['text'] as String, error: (j['error'] as bool?) ?? false);
}

class Conversation {
  final String id;
  String title;
  final List<ChatMessage> msgs;
  int updated;
  Conversation({required this.id, required this.title, required this.msgs, required this.updated});

  Map<String, dynamic> toJson() =>
      {'id': id, 'title': title, 'updated': updated, 'msgs': msgs.map((m) => m.toJson()).toList()};
  factory Conversation.fromJson(Map<String, dynamic> j) => Conversation(
        id: j['id'] as String,
        title: j['title'] as String,
        updated: (j['updated'] as num?)?.toInt() ?? 0,
        msgs: (j['msgs'] as List<dynamic>).map((m) => ChatMessage.fromJson(m as Map<String, dynamic>)).toList(),
      );
}

final AppState app = AppState();

class AppState extends ChangeNotifier {
  final VoiceService voice = VoiceService();
  SharedPreferences? _prefs;
  final FlutterSecureStorage _secure = const FlutterSecureStorage();
  String _memKey = '';

  // Settings
  String providerId = 'openai';
  String baseUrl = 'https://api.openai.com/v1';
  String model = 'gpt-4o-mini';
  String custom = defaultInstructions;
  String callName = 'sir';
  bool jarvisStyle = true;
  bool speakReplies = true;
  String voiceName = '';
  String voiceLocale = 'en-GB';
  double pitch = 0.82;
  double rate = 0.46;
  int themeIndex = 1; // 0 system, 1 dark, 2 light
  bool hasKey = false;
  List<Map<String, String>> voices = [];

  // Chats and live state
  List<Conversation> conversations = [];
  String? currentId;
  Status status = Status.idle;
  String partial = '';
  bool voiceMode = false;

  bool _handling = false;
  bool _sttTried = false;
  int _silentRounds = 0;

  ThemeMode get themeMode => const [ThemeMode.system, ThemeMode.dark, ThemeMode.light][themeIndex];

  Conversation? get current {
    for (final c in conversations) {
      if (c.id == currentId) return c;
    }
    return null;
  }

  String get greeting {
    final h = DateTime.now().hour;
    final part = h < 12 ? 'Good morning' : (h < 18 ? 'Good afternoon' : 'Good evening');
    return '$part, $callName.';
  }

  String get systemPrompt {
    final b = StringBuffer(custom.trim().isEmpty ? defaultInstructions : custom.trim());
    if (jarvisStyle) {
      b.write('\n\nPersonality: calm, composed, quietly witty and highly capable, like a refined British AI butler. '
          'Address the user as "$callName". Be concise: usually one to three sentences. Never use emojis. '
          'Your replies are often spoken aloud, so avoid markdown, lists and symbols unless the user asks for them.');
    } else {
      b.write('\n\nYour replies may be spoken aloud, so keep them concise.');
    }
    return b.toString();
  }

  // ---------- startup ----------
  Future<void> init() async {
    try {
      _prefs = await SharedPreferences.getInstance();
      _load();
    } catch (_) {}
    try {
      final k = await _secure.read(key: 'api_key');
      if (k != null) _memKey = k;
    } catch (_) {}
    hasKey = _memKey.isNotEmpty;
    await voice.initTts();
    await _applyVoice();
    voices = await voice.loadVoices();
  }

  void _load() {
    final p = _prefs;
    if (p == null) return;
    providerId = p.getString('provider') ?? providerId;
    baseUrl = p.getString('base') ?? baseUrl;
    model = p.getString('model') ?? model;
    custom = p.getString('custom') ?? custom;
    callName = p.getString('callName') ?? callName;
    jarvisStyle = p.getBool('jarvis') ?? jarvisStyle;
    speakReplies = p.getBool('speak') ?? speakReplies;
    voiceName = p.getString('voiceName') ?? voiceName;
    voiceLocale = p.getString('voiceLocale') ?? voiceLocale;
    pitch = p.getDouble('pitch') ?? pitch;
    rate = p.getDouble('rate') ?? rate;
    themeIndex = p.getInt('theme') ?? themeIndex;
    try {
      final raw = p.getString('chats');
      if (raw != null) {
        final list = jsonDecode(raw) as List<dynamic>;
        conversations = list.map((e) => Conversation.fromJson(e as Map<String, dynamic>)).toList();
        conversations.sort((a, b) => b.updated.compareTo(a.updated));
        if (conversations.isNotEmpty) currentId = conversations.first.id;
      }
    } catch (_) {
      conversations = [];
    }
  }

  void _persistChats() {
    final p = _prefs;
    if (p == null) return;
    if (conversations.length > 60) conversations = conversations.sublist(0, 60);
    p.setString('chats', jsonEncode(conversations.map((c) => c.toJson()).toList()));
  }

  Future<void> _applyVoice() =>
      voice.applyVoice(name: voiceName, locale: voiceLocale, pitch: pitch, rate: rate);

  Future<void> reapplyVoice() => _applyVoice();

  // ---------- settings ----------
  Future<void> saveSettings({
    required String providerId,
    required String baseUrl,
    required String model,
    required String custom,
    required String callName,
    required bool jarvisStyle,
    required bool speakReplies,
    required String voiceName,
    required String voiceLocale,
    required double pitch,
    required double rate,
    required int themeIndex,
    required String newKey,
  }) async {
    this.providerId = providerId;
    this.baseUrl = baseUrl;
    this.model = model;
    this.custom = custom;
    this.callName = callName;
    this.jarvisStyle = jarvisStyle;
    this.speakReplies = speakReplies;
    this.voiceName = voiceName;
    this.voiceLocale = voiceLocale;
    this.pitch = pitch;
    this.rate = rate;
    this.themeIndex = themeIndex;
    final p = _prefs;
    if (p != null) {
      await p.setString('provider', providerId);
      await p.setString('base', baseUrl);
      await p.setString('model', model);
      await p.setString('custom', custom);
      await p.setString('callName', callName);
      await p.setBool('jarvis', jarvisStyle);
      await p.setBool('speak', speakReplies);
      await p.setString('voiceName', voiceName);
      await p.setString('voiceLocale', voiceLocale);
      await p.setDouble('pitch', pitch);
      await p.setDouble('rate', rate);
      await p.setInt('theme', themeIndex);
    }
    if (newKey.trim().isNotEmpty) await setApiKey(newKey);
    await _applyVoice();
    notifyListeners();
  }

  Future<void> setApiKey(String key) async {
    _memKey = key.trim();
    hasKey = _memKey.isNotEmpty;
    try {
      if (_memKey.isEmpty) {
        await _secure.delete(key: 'api_key');
      } else {
        await _secure.write(key: 'api_key', value: _memKey);
      }
    } catch (_) {}
    notifyListeners();
  }

  Future<String> testConnection({
    required String provider,
    required String base,
    required String model,
    String key = '',
  }) async {
    final k = key.trim().isNotEmpty ? key.trim() : _memKey;
    try {
      await AiClient.chat(
        providerId: provider,
        baseUrl: base,
        model: model,
        apiKey: k,
        system: '',
        messages: [
          {'role': 'user', 'content': 'Reply with the single word: OK'}
        ],
      );
      return 'Connected ✓';
    } catch (e) {
      return e.toString();
    }
  }

  Future<void> previewVoice(String name, String locale, double p, double r, String text) async {
    await voice.applyVoice(name: name, locale: locale, pitch: p, rate: r);
    await voice.speak(text);
  }

  Future<void> speakText(String text) async {
    await voice.stopSpeaking();
    status = Status.speaking;
    notifyListeners();
    await voice.speak(text);
    if (status == Status.speaking) status = Status.idle;
    notifyListeners();
  }

  // ---------- chats ----------
  void newChat() {
    currentId = null;
    notifyListeners();
  }

  void openChat(String id) {
    currentId = id;
    notifyListeners();
  }

  void deleteChat(String id) {
    conversations.removeWhere((c) => c.id == id);
    if (currentId == id) currentId = null;
    _persistChats();
    notifyListeners();
  }

  void clearChats() {
    conversations = [];
    currentId = null;
    _persistChats();
    notifyListeners();
  }

  void _ensureConversation(String firstText) {
    if (current != null) return;
    final c = Conversation(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      title: firstText.length > 40 ? firstText.substring(0, 40) : firstText,
      msgs: [],
      updated: DateTime.now().millisecondsSinceEpoch,
    );
    conversations.insert(0, c);
    currentId = c.id;
  }

  void _add(String role, String text, {bool error = false}) {
    _ensureConversation(text);
    final c = current!;
    c.msgs.add(ChatMessage(role, text, error: error));
    c.updated = DateTime.now().millisecondsSinceEpoch;
    conversations.sort((a, b) => b.updated.compareTo(a.updated));
    _persistChats();
    notifyListeners();
  }

  List<Map<String, String>> _history() {
    final c = current;
    if (c == null) return [];
    var list = c.msgs.where((m) => !m.error).toList();
    if (list.length > 20) list = list.sublist(list.length - 20);
    while (list.isNotEmpty && list.first.role != 'user') {
      list.removeAt(0);
    }
    return list.map((m) => {'role': m.role, 'content': m.text}).toList();
  }

  Future<void> _say(String text, bool fromVoice) async {
    final on = fromVoice ? voiceMode : speakReplies;
    if (!on) {
      status = Status.idle;
      notifyListeners();
      return;
    }
    status = Status.speaking;
    notifyListeners();
    await voice.speak(text);
    if (status == Status.speaking) status = Status.idle;
    notifyListeners();
  }

  Future<String?> send(String raw, {bool fromVoice = false}) async {
    final text = raw.trim();
    if (text.isEmpty || status == Status.thinking) return null;
    _ensureConversation(text);
    _add('user', text);

    final local = await tryLocalCommand(text, callName);
    if (local != null) {
      _add('assistant', local);
      await _say(local, fromVoice);
      return local;
    }

    if (!hasKey) {
      final m = 'I need an API key first, $callName. Please open Settings and add one.';
      _add('assistant', m, error: true);
      await _say(m, fromVoice);
      return m;
    }

    status = Status.thinking;
    notifyListeners();
    try {
      final reply = await AiClient.chat(
        providerId: providerId,
        baseUrl: baseUrl,
        model: model,
        apiKey: _memKey,
        system: systemPrompt,
        messages: _history(),
      );
      _add('assistant', reply);
      await _say(reply, fromVoice);
      return reply;
    } catch (e) {
      final m = e.toString();
      _add('assistant', m, error: true);
      status = Status.idle;
      notifyListeners();
      if (fromVoice && voiceMode) {
        await _say('My apologies, $callName. That request failed.', true);
      }
      return null;
    }
  }

  // ---------- hands-free voice mode ----------
  Future<bool> _ensureStt() async {
    if (voice.sttReady) return true;
    voice.onStatus = _onSttStatus;
    voice.onError = _onSttError;
    final ok = await voice.initStt();
    _sttTried = true;
    return ok;
  }

  Future<void> startVoiceMode() async {
    voiceMode = true;
    _silentRounds = 0;
    _handling = false;
    notifyListeners();
    final ok = await _ensureStt();
    if (!ok) {
      final m = "I can't reach the microphone, $callName. Please allow microphone access "
          'and make sure speech recognition is installed on this phone.';
      _add('assistant', m, error: true);
      voiceMode = false;
      status = Status.idle;
      notifyListeners();
      return;
    }
    await _listen();
  }

  Future<void> _listen() async {
    if (!voiceMode || _handling) return;
    partial = '';
    status = Status.listening;
    notifyListeners();
    try {
      await voice.listen((words, isFinal) {
        partial = words;
        notifyListeners();
        if (isFinal && words.trim().isNotEmpty) _onFinal(words);
      });
    } catch (_) {
      await stopVoiceMode();
    }
  }

  bool _isExit(String s) {
    return RegExp(r"^(stop listening|stop|goodbye|good bye|that'?s all|that will be all|exit|end voice mode)$")
        .hasMatch(s);
  }

  Future<void> _onFinal(String words) async {
    if (_handling || !voiceMode) return;
    _handling = true;
    _silentRounds = 0;
    final lower = words.toLowerCase().trim().replaceAll(RegExp(r'[.!?,]+$'), '');
    if (_isExit(lower)) {
      partial = '';
      await _say('Very good, $callName. Standing by.', true);
      _handling = false;
      await stopVoiceMode();
      return;
    }
    partial = '';
    await send(words, fromVoice: true);
    _handling = false;
    if (voiceMode) {
      await Future.delayed(const Duration(milliseconds: 350));
      await _listen();
    }
  }

  void _onSttStatus(String s) {
    if ((s == 'done' || s == 'notListening') && voiceMode && !_handling && status == Status.listening) {
      Future.delayed(const Duration(milliseconds: 300), () async {
        if (!voiceMode || _handling || status != Status.listening) return;
        if (partial.trim().isNotEmpty) {
          _onFinal(partial);
          return;
        }
        _silentRounds++;
        if (_silentRounds >= 3) {
          await stopVoiceMode();
          return;
        }
        await _listen();
      });
    }
  }

  void _onSttError(String msg) {
    if (msg.contains('permission')) {
      stopVoiceMode();
    }
  }

  Future<void> stopVoiceMode() async {
    voiceMode = false;
    _handling = false;
    try {
      await voice.cancelListening();
      await voice.stopSpeaking();
    } catch (_) {}
    status = Status.idle;
    partial = '';
    notifyListeners();
  }

  Future<void> orbTap() async {
    if (!voiceMode) {
      await startVoiceMode();
      return;
    }
    if (status == Status.speaking) {
      await voice.stopSpeaking();
      return;
    }
    if (status == Status.listening) {
      await voice.stopListening();
      return;
    }
    if (status == Status.idle) {
      _silentRounds = 0;
      await _listen();
    }
  }

  bool get sttTried => _sttTried;
}
