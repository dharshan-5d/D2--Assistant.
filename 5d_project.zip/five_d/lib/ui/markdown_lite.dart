import 'package:flutter/material.dart';

/// Very small markdown renderer: **bold**, `code`, bullets, headings, code blocks.
class MarkdownLite extends StatelessWidget {
  final String text;
  final TextStyle style;
  final Color codeBg;
  const MarkdownLite({super.key, required this.text, required this.style, required this.codeBg});

  TextSpan _inline(String s) {
    final spans = <InlineSpan>[];
    final re = RegExp(r'(\*\*[^*]+\*\*|`[^`]+`)');
    var last = 0;
    for (final m in re.allMatches(s)) {
      if (m.start > last) spans.add(TextSpan(text: s.substring(last, m.start)));
      final tok = m.group(0)!;
      if (tok.startsWith('**')) {
        spans.add(TextSpan(text: tok.substring(2, tok.length - 2), style: const TextStyle(fontWeight: FontWeight.w700)));
      } else {
        spans.add(TextSpan(
          text: tok.substring(1, tok.length - 1),
          style: TextStyle(fontFamily: 'monospace', backgroundColor: codeBg, fontSize: (style.fontSize ?? 16) - 1),
        ));
      }
      last = m.end;
    }
    if (last < s.length) spans.add(TextSpan(text: s.substring(last)));
    return TextSpan(style: style, children: spans);
  }

  Widget _code(String code) {
    return Container(
      width: double.infinity,
      margin: const EdgeInsets.symmetric(vertical: 6),
      padding: const EdgeInsets.all(10),
      decoration: BoxDecoration(color: codeBg, borderRadius: BorderRadius.circular(10)),
      child: SingleChildScrollView(
        scrollDirection: Axis.horizontal,
        child: SelectableText(
          code.trimRight(),
          style: TextStyle(fontFamily: 'monospace', fontSize: (style.fontSize ?? 16) - 2, color: style.color),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final out = <Widget>[];
    final lines = text.split('\n');
    var inCode = false;
    final code = StringBuffer();
    final bullet = RegExp(r'^\s*([-*•]|\d+\.)\s+(.*)$');

    for (final line in lines) {
      if (line.trimLeft().startsWith('```')) {
        if (inCode) {
          out.add(_code(code.toString()));
          code.clear();
        }
        inCode = !inCode;
        continue;
      }
      if (inCode) {
        code.writeln(line);
        continue;
      }
      final trimmed = line.trim();
      if (trimmed.isEmpty) {
        out.add(const SizedBox(height: 6));
        continue;
      }
      if (trimmed.startsWith('#')) {
        final h = trimmed.replaceFirst(RegExp(r'^#+\s*'), '');
        out.add(Padding(
          padding: const EdgeInsets.only(top: 4, bottom: 2),
          child: SelectableText(h, style: style.copyWith(fontWeight: FontWeight.w700, fontSize: (style.fontSize ?? 16) + 1)),
        ));
        continue;
      }
      final b = bullet.firstMatch(line);
      if (b != null) {
        final marker = RegExp(r'^\d+\.$').hasMatch(b.group(1)!) ? '${b.group(1)} ' : '•  ';
        out.add(Padding(
          padding: const EdgeInsets.only(left: 4, top: 2, bottom: 2),
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(marker, style: style),
              Expanded(child: SelectableText.rich(_inline(b.group(2)!))),
            ],
          ),
        ));
        continue;
      }
      out.add(SelectableText.rich(_inline(line)));
    }
    if (inCode && code.isNotEmpty) out.add(_code(code.toString()));

    return Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisSize: MainAxisSize.min, children: out);
  }
}
