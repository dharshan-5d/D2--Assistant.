import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import '../state.dart';
import 'history_screen.dart';
import 'markdown_lite.dart';
import 'orb.dart';
import 'settings_screen.dart';
import 'voice_screen.dart';

const List<String> _suggestions = [
  'Set a timer for 5 minutes',
  'Turn on the flashlight',
  "What's my battery level?",
  'Explain black holes simply',
];

class ChatScreen extends StatefulWidget {
  const ChatScreen({super.key});

  @override
  State<ChatScreen> createState() => _ChatScreenState();
}

class _ChatScreenState extends State<ChatScreen> {
  final TextEditingController _input = TextEditingController();
  final ScrollController _scroll = ScrollController();
  int _lastCount = 0;

  @override
  void dispose() {
    _input.dispose();
    _scroll.dispose();
    super.dispose();
  }

  void _send() {
    final t = _input.text;
    if (t.trim().isEmpty) return;
    _input.clear();
    app.send(t);
  }

  void _toBottom() {
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 250),
          curve: Curves.easeOut,
        );
      }
    });
  }

  void _openVoice() {
    Navigator.push(
      context,
      MaterialPageRoute(fullscreenDialog: true, builder: (_) => const VoiceScreen()),
    );
  }

  void _openSettings() {
    Navigator.push(context, MaterialPageRoute(builder: (_) => const SettingsScreen()));
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final cs = Theme.of(context).colorScheme;
        final msgs = app.current?.msgs ?? <ChatMessage>[];
        if (msgs.length != _lastCount) {
          _lastCount = msgs.length;
          _toBottom();
        }
        return Scaffold(
          appBar: AppBar(
            titleSpacing: 16,
            title: Row(
              children: [
                Orb(size: 30, status: app.status),
                const SizedBox(width: 10),
                const Text('5D', style: TextStyle(fontWeight: FontWeight.w700, letterSpacing: 2)),
              ],
            ),
            actions: [
              IconButton(
                tooltip: 'New chat',
                icon: const Icon(Icons.add_comment_outlined),
                onPressed: () => app.newChat(),
              ),
              IconButton(
                tooltip: 'History',
                icon: const Icon(Icons.history),
                onPressed: () => Navigator.push(
                  context,
                  MaterialPageRoute(builder: (_) => const HistoryScreen()),
                ),
              ),
              IconButton(
                tooltip: 'Settings',
                icon: const Icon(Icons.settings_outlined),
                onPressed: _openSettings,
              ),
            ],
          ),
          body: SafeArea(
            child: Column(
              children: [
                Expanded(child: msgs.isEmpty ? _hero(context, cs) : _list(msgs, cs)),
                if (app.status == Status.thinking) const LinearProgressIndicator(minHeight: 2),
                _inputBar(cs),
              ],
            ),
          ),
        );
      },
    );
  }

  Widget _hero(BuildContext context, ColorScheme cs) {
    return Center(
      child: SingleChildScrollView(
        padding: const EdgeInsets.all(24),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            GestureDetector(onTap: _openVoice, child: Orb(size: 200, status: app.status)),
            const SizedBox(height: 16),
            Text(
              app.greeting,
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w600),
            ),
            const SizedBox(height: 6),
            Text(
              'Tap the orb to talk, or type below.',
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(color: cs.onSurfaceVariant),
            ),
            if (!app.hasKey) ...[
              const SizedBox(height: 16),
              FilledButton.tonalIcon(
                onPressed: _openSettings,
                icon: const Icon(Icons.key),
                label: const Text('Add your API key'),
              ),
            ],
            const SizedBox(height: 22),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              alignment: WrapAlignment.center,
              children: [
                for (final s in _suggestions) ActionChip(label: Text(s), onPressed: () => app.send(s)),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _list(List<ChatMessage> msgs, ColorScheme cs) {
    final maxW = MediaQuery.of(context).size.width * 0.84;
    return ListView.builder(
      controller: _scroll,
      padding: const EdgeInsets.fromLTRB(14, 8, 14, 8),
      itemCount: msgs.length,
      itemBuilder: (_, i) => _bubble(msgs[i], cs, maxW),
    );
  }

  Widget _mini(IconData icon, String tip, VoidCallback onTap) {
    return IconButton(
      visualDensity: VisualDensity.compact,
      iconSize: 18,
      tooltip: tip,
      onPressed: onTap,
      icon: Icon(icon),
    );
  }

  Widget _bubble(ChatMessage m, ColorScheme cs, double maxW) {
    final user = m.role == 'user';
    final Color bg = m.error
        ? cs.errorContainer
        : (user ? cs.primary.withAlpha(40) : cs.surfaceContainerHighest.withAlpha(150));
    final Color fg = m.error ? cs.onErrorContainer : cs.onSurface;
    final radius = BorderRadius.only(
      topLeft: const Radius.circular(18),
      topRight: const Radius.circular(18),
      bottomLeft: Radius.circular(user ? 18 : 4),
      bottomRight: Radius.circular(user ? 4 : 18),
    );
    final bodyStyle = TextStyle(color: fg, fontSize: 16, height: 1.4);
    return Align(
      alignment: user ? Alignment.centerRight : Alignment.centerLeft,
      child: Container(
        margin: const EdgeInsets.symmetric(vertical: 5),
        constraints: BoxConstraints(maxWidth: maxW),
        padding: const EdgeInsets.fromLTRB(14, 10, 14, 4),
        decoration: BoxDecoration(
          color: bg,
          borderRadius: radius,
          border: Border.all(color: user ? cs.primary.withAlpha(90) : cs.outlineVariant.withAlpha(120)),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          mainAxisSize: MainAxisSize.min,
          children: [
            if (user || m.error)
              SelectableText(m.text, style: bodyStyle)
            else
              MarkdownLite(text: m.text, style: bodyStyle, codeBg: cs.surface),
            if (!user && !m.error)
              Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  _mini(Icons.copy_rounded, 'Copy', () {
                    Clipboard.setData(ClipboardData(text: m.text));
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Copied'), duration: Duration(seconds: 1)),
                    );
                  }),
                  _mini(Icons.volume_up_rounded, 'Speak', () => app.speakText(m.text)),
                ],
              )
            else
              const SizedBox(height: 6),
          ],
        ),
      ),
    );
  }

  Widget _inputBar(ColorScheme cs) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(10, 6, 10, 10),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          IconButton.filledTonal(
            onPressed: _openVoice,
            tooltip: 'Voice mode',
            icon: const Icon(Icons.mic_rounded),
          ),
          const SizedBox(width: 8),
          Expanded(
            child: TextField(
              controller: _input,
              minLines: 1,
              maxLines: 5,
              textCapitalization: TextCapitalization.sentences,
              decoration: InputDecoration(
                hintText: 'Message 5D',
                filled: true,
                fillColor: cs.surfaceContainerHighest.withAlpha(120),
                contentPadding: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(26),
                  borderSide: BorderSide.none,
                ),
              ),
            ),
          ),
          const SizedBox(width: 8),
          IconButton.filled(
            onPressed: app.status == Status.thinking ? null : _send,
            tooltip: 'Send',
            icon: const Icon(Icons.arrow_upward_rounded),
          ),
        ],
      ),
    );
  }
}
