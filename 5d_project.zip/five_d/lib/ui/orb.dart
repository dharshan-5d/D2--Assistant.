import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../state.dart';

/// Animated "arc reactor" style orb that reacts to the assistant status.
class Orb extends StatefulWidget {
  final double size;
  final Status status;
  const Orb({super.key, required this.size, required this.status});

  @override
  State<Orb> createState() => _OrbState();
}

class _OrbState extends State<Orb> with SingleTickerProviderStateMixin {
  late final AnimationController _c =
      AnimationController(vsync: this, duration: const Duration(seconds: 8))..repeat();

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final color = Theme.of(context).colorScheme.primary;
    return SizedBox(
      width: widget.size,
      height: widget.size,
      child: AnimatedBuilder(
        animation: _c,
        builder: (context, _) => CustomPaint(painter: _OrbPainter(_c.value, widget.status, color)),
      ),
    );
  }
}

class _OrbPainter extends CustomPainter {
  final double t;
  final Status status;
  final Color color;
  _OrbPainter(this.t, this.status, this.color);

  @override
  void paint(Canvas canvas, Size size) {
    final c = size.center(Offset.zero);
    final r = size.width / 2;
    const tau = math.pi * 2;

    final (int breathK, double amp, int spinK) = switch (status) {
      Status.idle => (1, 0.025, 1),
      Status.listening => (4, 0.06, 2),
      Status.thinking => (3, 0.04, 8),
      Status.speaking => (10, 0.09, 3),
    };
    final pulse = math.sin(tau * breathK * t) * amp;

    // soft glow
    final glow = Paint()
      ..shader = RadialGradient(colors: [color.withAlpha(150), color.withAlpha(0)])
          .createShader(Rect.fromCircle(center: c, radius: r));
    canvas.drawCircle(c, r * (0.95 + pulse), glow);

    // rings
    final ring = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.5;
    for (var i = 0; i < 3; i++) {
      ring.color = color.withAlpha(90 - i * 22);
      canvas.drawCircle(c, r * (0.40 + i * 0.16 + pulse * (i + 1) * 0.5), ring);
    }

    // spinning arcs
    final arc = Paint()
      ..style = PaintingStyle.stroke
      ..strokeCap = StrokeCap.round;
    for (var i = 0; i < 3; i++) {
      final dir = i.isEven ? 1.0 : -1.0;
      arc.strokeWidth = 3.0 - i * 0.6;
      arc.color = color.withAlpha(230 - i * 50);
      final rect = Rect.fromCircle(center: c, radius: r * (0.52 + i * 0.16));
      final start = tau * spinK * (i + 1) * dir * t;
      canvas.drawArc(rect, start, 1.3 + i * 0.4, false, arc);
      canvas.drawArc(rect, start + math.pi, 0.7, false, arc);
    }

    // listening ripple
    if (status == Status.listening) {
      final p = (t * 4) % 1.0;
      final rp = Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2
        ..color = color.withAlpha((120 * (1 - p)).round());
      canvas.drawCircle(c, r * (0.45 + 0.5 * p), rp);
    }

    // bright core
    final core = Paint()
      ..shader = RadialGradient(
        colors: [Colors.white, color.withAlpha(220), color.withAlpha(0)],
        stops: const [0.0, 0.45, 1.0],
      ).createShader(Rect.fromCircle(center: c, radius: r * 0.28));
    canvas.drawCircle(c, r * (0.2 + pulse * 1.2), core);
  }

  @override
  bool shouldRepaint(covariant _OrbPainter old) => true;
}
