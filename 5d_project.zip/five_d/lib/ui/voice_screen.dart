import 'package:flutter/material.dart';

import '../state.dart';
import 'orb.dart';

class VoiceScreen extends StatefulWidget {
  const VoiceScreen({super.key});

  @override
  State<VoiceScreen> createState() => _VoiceScreenState();
}

class _VoiceScreenState extends State<VoiceScreen> {
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => app.startVoiceMode());
  }

  @override
  void dispose() {
    Future.microtask(() => app.stopVoiceMode());
    super.dispose();
  }

  String _label() {
    switch (app.status) {
      case Status.listening:
        return 'Listening…';
      case Status.thinking:
        return 'Thinking…';
      case Status.speaking:
        return 'Speaking…';
      case Status.idle:
        return app.voiceMode ? 'Ready' : 'Tap the orb to talk';
    }
  }

  String _caption() {
    if (app.status == Status.listening && app.partial.trim().isNotEmpty) return app.partial;
    final msgs = app.current?.msgs ?? <ChatMessage>[];
    if (msgs.isNotEmpty) return msgs.last.text;
    return 'Say "stop listening" or "goodbye" to end.';
  }

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: app,
      builder: (context, _) {
        final cs = Theme.of(context).colorScheme;
        return Scaffold(
          body: Container(
            decoration: BoxDecoration(
              gradient: RadialGradient(
                center: const Alignment(0, -0.25),
                radius: 1.1,
                colors: [cs.primary.withAlpha(45), cs.surface],
              ),
            ),
            child: SafeArea(
              child: Column(
                children: [
                  Align(
                    alignment: Alignment.topLeft,
                    child: IconButton(
                      icon: const Icon(Icons.close_rounded),
                      onPressed: () => Navigator.pop(context),
                    ),
                  ),
                  const Spacer(),
                  GestureDetector(onTap: () => app.orbTap(), child: Orb(size: 260, status: app.status)),
                  const SizedBox(height: 24),
                  Text(
                    _label(),
                    style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 12),
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 28),
                    child: ConstrainedBox(
                      constraints: const BoxConstraints(maxHeight: 170),
                      child: SingleChildScrollView(
                        child: Text(
                          _caption(),
                          textAlign: TextAlign.center,
                          style: Theme.of(context).textTheme.bodyLarge?.copyWith(color: cs.onSurfaceVariant),
                        ),
                      ),
                    ),
                  ),
                  const Spacer(),
                  Padding(
                    padding: const EdgeInsets.only(bottom: 24),
                    child: OutlinedButton.icon(
                      onPressed: () => Navigator.pop(context),
                      icon: const Icon(Icons.stop_circle_outlined),
                      label: const Text('End voice mode'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        );
      },
    );
  }
}
