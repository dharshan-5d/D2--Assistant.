import 'package:flutter/material.dart';

import '../api.dart';
import '../state.dart';

class SettingsScreen extends StatefulWidget {
  const SettingsScreen({super.key});

  @override
  State<SettingsScreen> createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  late String _provider = app.providerId;
  late final TextEditingController _base = TextEditingController(text: app.baseUrl);
  late final TextEditingController _model = TextEditingController(text: app.model);
  final TextEditingController _key = TextEditingController();
  late final TextEditingController _custom = TextEditingController(text: app.custom);
  late final TextEditingController _call = TextEditingController(text: app.callName);
  late bool _jarvis = app.jarvisStyle;
  late bool _speak = app.speakReplies;
  late String _voiceName = app.voiceName;
  late String _voiceLocale = app.voiceLocale;
  late double _pitch = app.pitch;
  late double _rate = app.rate;
  late int _theme = app.themeIndex;
  bool _showKey = false;
  bool _testing = false;
  String _test = '';

  @override
  void dispose() {
    _base.dispose();
    _model.dispose();
    _key.dispose();
    _custom.dispose();
    _call.dispose();
    app.reapplyVoice();
    super.dispose();
  }

  String get _who => _call.text.trim().isEmpty ? 'sir' : _call.text.trim();

  void _pickProvider(String? id) {
    if (id == null) return;
    final p = providerOf(id);
    setState(() {
      _provider = id;
      _base.text = p.baseUrl;
      _model.text = p.model;
      _test = '';
    });
  }

  Future<void> _runTest() async {
    setState(() {
      _testing = true;
      _test = 'Testing…';
    });
    final r = await app.testConnection(
      provider: _provider,
      base: _base.text,
      model: _model.text,
      key: _key.text,
    );
    if (!mounted) return;
    setState(() {
      _testing = false;
      _test = r;
    });
  }

  void _preview() {
    app.previewVoice(
      _voiceName,
      _voiceLocale,
      _pitch,
      _rate,
      'Good evening, $_who. All systems are running at full capacity.',
    );
  }

  void _jarvisPreset() {
    setState(() {
      _voiceLocale = 'en-GB';
      _pitch = 0.82;
      _rate = 0.46;
      final gb = app.voices
          .where((v) => v['locale']!.toLowerCase().replaceAll('_', '-') == 'en-gb')
          .toList();
      _voiceName = gb.isNotEmpty ? gb.first['name']! : '';
    });
    _preview();
  }

  Future<void> _save() async {
    await app.saveSettings(
      providerId: _provider,
      baseUrl: _base.text.trim(),
      model: _model.text.trim(),
      custom: _custom.text,
      callName: _who,
      jarvisStyle: _jarvis,
      speakReplies: _speak,
      voiceName: _voiceName,
      voiceLocale: _voiceLocale,
      pitch: _pitch,
      rate: _rate,
      themeIndex: _theme,
      newKey: _key.text,
    );
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Saved')));
    Navigator.pop(context);
  }

  List<DropdownMenuItem<String>> _voiceItems() {
    final list = app.voices.where((v) => v['locale']!.toLowerCase().startsWith('en')).toList();
    list.sort((a, b) {
      final ga = a['locale']!.toLowerCase().contains('gb') ? 0 : 1;
      final gb = b['locale']!.toLowerCase().contains('gb') ? 0 : 1;
      if (ga != gb) return ga - gb;
      return a['name']!.compareTo(b['name']!);
    });
    return [
      const DropdownMenuItem<String>(value: '', child: Text('Automatic (UK English)')),
      for (final v in list)
        DropdownMenuItem<String>(
          value: v['name']!,
          child: Text('${v['locale']} · ${v['name']}', overflow: TextOverflow.ellipsis),
        ),
    ];
  }

  Widget _section(String title, List<Widget> children) {
    final cs = Theme.of(context).colorScheme;
    return Container(
      margin: const EdgeInsets.only(bottom: 16),
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: cs.surfaceContainerHighest.withAlpha(90),
        borderRadius: BorderRadius.circular(18),
        border: Border.all(color: cs.outlineVariant.withAlpha(120)),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          ...children,
        ],
      ),
    );
  }

  Widget _gap() => const SizedBox(height: 12);

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final items = _voiceItems();
    final names = items.map((e) => e.value).toList();
    final voiceValue = names.contains(_voiceName) ? _voiceName : '';

    return Scaffold(
      appBar: AppBar(
        title: const Text('Settings'),
        actions: [TextButton(onPressed: _save, child: const Text('Save'))],
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            _section('AI connection', [
              DropdownButtonFormField<String>(
                value: _provider,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Provider', border: OutlineInputBorder()),
                items: [
                  for (final p in providers) DropdownMenuItem<String>(value: p.id, child: Text(p.label)),
                ],
                onChanged: _pickProvider,
              ),
              _gap(),
              TextField(
                controller: _base,
                keyboardType: TextInputType.url,
                decoration: const InputDecoration(labelText: 'Base URL (https)', border: OutlineInputBorder()),
              ),
              _gap(),
              TextField(
                controller: _model,
                decoration: const InputDecoration(labelText: 'Model name', border: OutlineInputBorder()),
              ),
              _gap(),
              TextField(
                controller: _key,
                obscureText: !_showKey,
                autocorrect: false,
                enableSuggestions: false,
                decoration: InputDecoration(
                  labelText: app.hasKey ? 'API key (saved, leave empty to keep)' : 'API key',
                  border: const OutlineInputBorder(),
                  suffixIcon: IconButton(
                    icon: Icon(_showKey ? Icons.visibility_off : Icons.visibility),
                    onPressed: () => setState(() => _showKey = !_showKey),
                  ),
                ),
              ),
              _gap(),
              Row(
                children: [
                  OutlinedButton.icon(
                    onPressed: _testing ? null : _runTest,
                    icon: const Icon(Icons.wifi_tethering),
                    label: const Text('Test connection'),
                  ),
                ],
              ),
              if (_test.isNotEmpty) ...[
                const SizedBox(height: 8),
                Text(
                  _test,
                  style: TextStyle(color: _test.startsWith('Connected') ? cs.primary : cs.error),
                ),
              ],
              const SizedBox(height: 8),
              Text(
                'Model names change over time. If you get a "not found" error, copy the current model name from your provider.',
                style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
              ),
            ]),
            _section('Assistant', [
              TextField(
                controller: _call,
                decoration: const InputDecoration(labelText: 'Address me as', border: OutlineInputBorder()),
              ),
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Butler style replies'),
                subtitle: const Text('Calm, witty and short, like a British AI butler'),
                value: _jarvis,
                onChanged: (v) => setState(() => _jarvis = v),
              ),
              TextField(
                controller: _custom,
                minLines: 3,
                maxLines: 6,
                decoration: const InputDecoration(labelText: 'Extra instructions', border: OutlineInputBorder()),
              ),
            ]),
            _section('Voice', [
              SwitchListTile(
                contentPadding: EdgeInsets.zero,
                title: const Text('Speak replies aloud'),
                value: _speak,
                onChanged: (v) => setState(() => _speak = v),
              ),
              FilledButton.tonalIcon(
                onPressed: _jarvisPreset,
                icon: const Icon(Icons.record_voice_over),
                label: const Text('Use butler voice preset'),
              ),
              _gap(),
              DropdownButtonFormField<String>(
                value: voiceValue,
                isExpanded: true,
                decoration: const InputDecoration(labelText: 'Voice', border: OutlineInputBorder()),
                items: items,
                onChanged: (v) {
                  if (v == null) return;
                  setState(() {
                    _voiceName = v;
                    if (v.isEmpty) {
                      _voiceLocale = 'en-GB';
                    } else {
                      for (final e in app.voices) {
                        if (e['name'] == v) _voiceLocale = e['locale']!;
                      }
                    }
                  });
                },
              ),
              const SizedBox(height: 8),
              Text('Pitch  ${_pitch.toStringAsFixed(2)}'),
              Slider(
                value: _pitch,
                min: 0.5,
                max: 1.5,
                onChanged: (v) => setState(() => _pitch = v),
              ),
              Text('Speed  ${_rate.toStringAsFixed(2)}'),
              Slider(
                value: _rate,
                min: 0.2,
                max: 0.8,
                onChanged: (v) => setState(() => _rate = v),
              ),
              OutlinedButton.icon(
                onPressed: _preview,
                icon: const Icon(Icons.play_arrow_rounded),
                label: const Text('Preview voice'),
              ),
              const SizedBox(height: 8),
              Text(
                'Voices come from your phone. For the deepest British male voice, open Android Settings, '
                'search "Text-to-speech output", install English (UK) voice data, then pick a UK voice here '
                'and lower the pitch a little. Try each UK voice with Preview.',
                style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
              ),
            ]),
            _section('Appearance', [
              SegmentedButton<int>(
                segments: const [
                  ButtonSegment<int>(value: 0, label: Text('System')),
                  ButtonSegment<int>(value: 1, label: Text('Dark')),
                  ButtonSegment<int>(value: 2, label: Text('Light')),
                ],
                selected: {_theme},
                onSelectionChanged: (s) => setState(() => _theme = s.first),
              ),
            ]),
            _section('Data and privacy', [
              Text(
                'Your API key is stored with the Android Keystore. Chats are stored on this phone only. '
                'Messages go to the provider you choose, and voice recognition uses your phone\'s speech service. '
                'Anyone who can unlock your phone and open this app can use it, so keep a screen lock on.',
                style: TextStyle(fontSize: 12, color: cs.onSurfaceVariant),
              ),
              const SizedBox(height: 12),
              Wrap(
                spacing: 8,
                children: [
                  OutlinedButton(
                    onPressed: () {
                      app.clearChats();
                      ScaffoldMessenger.of(context)
                          .showSnackBar(const SnackBar(content: Text('Chats cleared')));
                    },
                    child: const Text('Clear all chats'),
                  ),
                  if (app.hasKey)
                    OutlinedButton(
                      onPressed: () async {
                        await app.setApiKey('');
                        if (mounted) setState(() {});
                      },
                      child: Text('Delete saved key', style: TextStyle(color: cs.error)),
                    ),
                ],
              ),
            ]),
            FilledButton(onPressed: _save, child: const Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Text('Save'),
            )),
            const SizedBox(height: 24),
          ],
        ),
      ),
    );
  }
}
